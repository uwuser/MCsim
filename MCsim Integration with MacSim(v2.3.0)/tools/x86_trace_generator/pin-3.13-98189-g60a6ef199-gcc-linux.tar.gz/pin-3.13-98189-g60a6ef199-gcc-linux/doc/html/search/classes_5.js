var searchData=
[
  ['hexstr',['HEXSTR',['../structLEVEL__BASE_1_1HEXSTR.html',1,'LEVEL_BASE']]]
];
