var searchData=
[
  ['gettoolnameargs',['GetToolNameArgs',['../classLEVEL__BASE_1_1PARSER.html#a76d0e910d648bc7b26d8043da5c4abfd',1,'LEVEL_BASE::PARSER']]],
  ['generic_20inspection_20api',['Generic inspection API',['../group__INS__BASIC__API__GEN__IA32.html',1,'']]],
  ['generic_20modification_20api',['Generic modification API',['../group__INS__MOD__API__GEN__IA32.html',1,'']]]
];
