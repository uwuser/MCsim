var searchData=
[
  ['readers_20writers_20lock',['Readers writers lock',['../group__OS__APIS__RW__LOCK.html',1,'']]]
];
