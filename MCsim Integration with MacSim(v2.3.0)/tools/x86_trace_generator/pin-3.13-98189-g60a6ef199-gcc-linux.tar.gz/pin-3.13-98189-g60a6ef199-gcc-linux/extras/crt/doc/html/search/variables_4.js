var searchData=
[
  ['os_5fspecific_5ferr',['os_specific_err',['../struct__OS__RETURN__CODE.html#acba8ab3ec82ed89c8f28ed2933c804fa',1,'_OS_RETURN_CODE']]]
];
